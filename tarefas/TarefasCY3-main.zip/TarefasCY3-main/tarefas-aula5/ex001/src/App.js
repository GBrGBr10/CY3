import logo from './logo.svg';
import './App.css';
import Pizza from './componentes/Pizza';
import PostInstagram from './componentes/PostInstagram';

function App() {
  return (
    <div>
      <h1>ex001</h1>
      <Pizza />
      <Pizza />
      <Pizza />

      <PostInstagram />
    </div>
  );
}

export default App;
