import './Pizza.css';

function Pizza() {
    return(
        <div className='Pizza'>
            <p>Pizza!</p>
            <img src="frangocatupiry.jpg" alt="float: right;" />
        </div>
    );
}

export default Pizza;