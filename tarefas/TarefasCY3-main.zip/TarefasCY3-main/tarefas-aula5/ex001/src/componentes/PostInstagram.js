import './PostInstagram.css'

function PostInstagram () {
    return(
        <div class="centraliza">
        <div class="post">
        <div>
            <img src="https://i.pravatar.cc/40" alt="" />
            <span><strong>Lucas71</strong></span>
        </div>

        <img src="https://picsum.photos/300/200" alt="" />

        <div>
            ❤️513K💬40.1K🚩17.8K
        </div>

        <div>
            <strong>Lucas71</strong> Esse lugar é muito lindo, alguém topa ir cmg? 🫠
        </div>

        </div>
        </div>
    )
}

export default PostInstagram;